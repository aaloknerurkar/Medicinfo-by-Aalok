-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2016 at 06:31 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medicinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `Did` int(4) NOT NULL,
  `Dname` varchar(50) NOT NULL,
  `Ddesc` text NOT NULL,
    `Dno` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Did`, `Dname`, `Ddesc`, `Dno`) VALUES
(1, 'Doctor specialzes in Anemia', 'Dr. ABC- In the United States alone there are nearly 700,000 physicians. In appreciation of doctors and physicians, National Doctors Day is celebrated on March 30 every year, commemorating the day that general anesthesia was used in surgery for the first time.', '807-356-1234'),
(2, 'Doctor specialzes in Diarrhea', 'Dr. XYZ- Doctors are just as likely to abuse alcohol and illegal drugs as the average citizen, but are much more likely to abuse prescription drugs due to close proximity and easier procurement. They are also more likely to have a relapse later for the same reasons.', '807-356-5678'),
(3, 'Doctor specialzes in Lung Cancer', 'Dr. PQR- Despite popular belief, doctors are not usually paid to promote a certain drug or device to the patient they are treating. Instead, many doctors may be paid by pharmaceutical companies and device makers to either give talks to groups of patients or doctors about a product, provide advice to companies on clinical trial designs or, less commonly, to conduct research trials at their practices.', '807-356-5378'),
(4, 'Doctor specialzes in Coronary Artery Diseases', 'Dr. DEF- About 64% of physicians report working overtime. Some physicians may work as many as 60 hours per week.', '807-356-2790'),
(5, 'Doctor specialzes in Adenovirus Infection', 'Dr. QST- Doctors leave sponges and other medical devices inside of their patients about 6,000 times a year.', '807-356-4268'),
(6, 'Doctor specialzes in Arthritis', 'Dr. HIJ- Although being a physician is one of the highest-paid careers, many doctors seek additional part-time work to help pay off medical school debt.', '807-356-9347'),
(7, 'Doctor specialzes in Type-2 Diabetes', 'Dr. QWE- Physicians and doctors are among one of the highest paid careers, and the job growth for the field is growing faster than average for all occupations. Growth is estimated to be at 18% between 2012 to 2020 and is attributed to continued expansion of health care-related industries, high demand in rural and low-income areas, and the increased demand in care for baby boomers.', '807-356-1286'),
(8, 'Doctor specialzes in Sleeping sickness', 'Dr. BNM- The earliest written record that mentions the practice of medicine is Hammurabis Code from the 18th century BC in Mesopotamia. This extensive code of laws includes information for physicians about payments for successful treatments and punishments for medical failures. For example, payment was better for curing the wealthy, but failing to do so could result in the loss of a hand.', '807-356-6894'),
(9, 'Doctor specialzes in Stroke', 'Dr. IOP- Researchers suspect that at about 4000 BC the ancient Greeks had the first designated housings for healing the sick. Instead of a formal hospital with physicians, however, they were most likely temples devoted to gods of healing such as Saturn and Asclepius that may or may not have had a separate room serving as a clinic. The sick were dropped off to pray and ask for healing from the gods.', '807-356-3579'),
(10, 'Doctor specialzes in Chronic Obstructive Pulmonary Diseases', 'Dr. YUI- The earliest documentation for a formal hospital with physicians that treated the ill comes from the 5th century BC in Sri Lanka.', '807-356-6447'),
(11, 'Doctor specialzes in Fungal Eye Infections', 'Dr. JKL- Ancient Native American tribes in North America practiced a mix of magical and religious healing. However, many of their techniques were rather sophisticated, such as midwives being able to check fetal positions, watching and monitoring the mothers diet, and speeding the birthing process with infusions.', '807-356-4468'),
(12, 'Doctor specialzes in Avian Influenza', 'Dr. ASD- In early Asian civilizations, the practice of medicine by physicians was particularly advanced for the time, with surgical techniques in India including the removal of tumors, bladder stones, and even cataracts. Chinese physicians even had knowledge of using many different herbal, mineral, and animal products for treatment of disease.', '807-356-7943'),
(13, 'Doctor specialzes in Dengue', 'Dr. FGH- Asclepius was a Greek god of the medical art, thought to have been the son of Apollo brought up and instructed in the art of healing by Chiron. Later stories would have him as a skilled physician of Epidaurus, who was killed by Zeus for enabling humans to escape death. Asclepius is thought to be based upon a real person who lived in 1200 BC that had performed many miracles of healing.', '807-356-4678'),
(14, 'Doctor specialzes in Venous Thromboembolism (Blood clots)', 'Dr. JKL- Hippocrates (460–377 BC) is commonly called the "Father of Medicine" or the "Father of Western Medicine." He is thought to be one of the first physicians to treat disease as being a result of natural rather than supernatural causes. He also founded the Hippocratic School, a medical school that focused on the healing power of nature as well as the importance of physical observation and the act of prognosis.', '807-356-4789'),
(15, 'Doctor specialzes in Lassa fever', 'Dr. VBN- Medical practitioners in ancient Greece placed magical significance on the number 4, a practice that would last for almost 2,000 years. Significance was gained from the four seasons and the four earthly elements of air, fire, earth, and water. Medicine centered around keeping the four humors in balance in the body, which were thought to be sanguine (blood), choleric (yellow bile), melancholic (black bile), and phlegmatic (phlegm).', '807-356-9900'),
(16, 'Doctor specialzes in Lead Poisoning', 'Dr. FGH- During Europe’s Dark Ages, ca. 476 AD to the 14th century AD, many diseases were thought to be caused by an excess or plethora of blood. Bloodletting with incisions or leeches was a cure-all during the time and was so popular that physicians themselves were commonly referred to as "leeches."', '807-356-2457'),
(17, 'Doctor specialzes in Foodborne Germs and Illnesses', 'Dr. XCV- A study performed by the University of Chicago found that most of todays physicians believe religion/spirituality has much or very much influence on a patients health, although few (about 6% of responders) believe that it affected "hard" medical outcomes. Instead, the physicians were inclined to believe that religion helps patients cope and remain more positive and provides emotional support.', '807-356-4678'),
(18, 'Doctor specialzes in Typhoid Fever', 'Dr. ZXC- A study performed in the United States found that surgeons who played video games on a regular basis made 37% less errors and were 27% faster than their nongaming coworkers.', '807-356-5437'),
(19, 'Doctor specialzes in Influenza flu', 'Dr. QOF- On average, surgeons interrupt their patients during a consultation once every 14 seconds. The busier a surgeon tends to be, the more likely they are to interrupt.', '807-356-4678'),
(20, 'Doctor specialzes in Tuberculosis(TB)', 'Dr. SOJ- Medical errors are counted as one of the leading causes of death and injury in the United States. It is estimated that about 98,000 people die each year in U.S. hospitals as a result of medical error.', '807-356-5789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `disease`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`Did`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `disease`
--
ALTER TABLE `doctor`
  MODIFY `Did` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
