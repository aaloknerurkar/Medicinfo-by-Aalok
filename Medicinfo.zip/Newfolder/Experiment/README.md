# hypochondriapp

Enter  your symptoms. Get back the scariest sounding disease possible.

View live: http://hypochondriapp.io

![alt tag](screenshot.png)

Hypochondriapp is a spoof on the modern phenomenon of web-induced hypochondria. It was made for the 2017 [Stupid Shit No One Needs and Terrible Ideas Hackathon](https://stupidhackathon.com/).

Hypochondriapp was built using Python, Javascript, JQuery, and Flexbox. It scrapes Wikipedia's rare diseases section, and simply returns one of the diseases with the top 3 longest names that matches any one of your entered symptoms.

Shoutouts: This app is a remake of an [old project](https://github.com/hypochondriapp/hypochondriapp) I did back in 2013 with collaborators Greg Eng and David Bella.