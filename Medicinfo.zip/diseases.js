var diseases = {
    "Oguchi disease": {
        "summary": "Oguchi disease, also called congenital stationary night blindness, Oguchi type 1 or Oguchi disease 1, is an autosomal recessive form of congenital stationary night blindness associated with fundus discoloration and abnormally slow dark adaptation.",
         "symptoms": ["red eyes", "diplopia", "edema", "phobia", "blindness", "inflammation", "nystagmus", "exophthalmos", "ptosis", "myopathy"],
        "url": "https://en.wikipedia.org/wiki/Oguchi_disease"
    },
    "Adenosine monophosphate deaminase deficiency type 1": {
        "summary": "Adenosine monophosphate deaminase deficiency type 1, also called myoadenylate deaminase deficiency (MADD), is a recessive genetic metabolic disorder that affects approximately 1\u20132% of populations of European descent. It appears to be considerably rarer in Asian populations. The genetic form is caused by a defect in the gene for AMP deaminase though there is also an acquired form of AMP deficiency.",
        "symptoms": ["red eyes", "weak1", "palpitation", "inflammation", "irritation", "hyperthermia", "muscle cramp", "muscle weakness", "fatigue", "gas", "myopathy"],
        "url": "https://en.wikipedia.org/wiki/Adenosine_monophosphate_deaminase_deficiency_type_1"
    },
    "AIDS & HIV": {
        "summary": "When a person is first exposed to HIV, they may show no symptoms for several months or longer. Typically, however, they experience a flu-like illness that includes fever, chills, headache, fatigue, muscle aches and enlarged lymph nodes in the neck and groin areas. This early illness is often followed by a “latency” phase where the virus is less active and no symptoms are present, according to the U.S. Department of Health and Human Services. This latent period can last up to a decade or more.",
        "symptoms": ["weight loss", "extreme fatigue", "night sweats", "fever", "prolonged gland swelling"],
        "url": "https://en.wikipedia.org/wiki/Aids"
    },
    "Bladder Cancer": {
        "summary": "Bladder cancer is a cancer of the lining of the bladder, a piece of muscle that has multiple layers. Bladder cancer occurs more frequently among older men, with the median age of diagnosis being 73 and the media age of death being 78, based on data collected in the United States from 2003 to 2007. The National Cancer Institute estimates that that there will be 74,690 new cases and 15,580 deaths from bladder cancer in the United States in 2014. About 70 to 80 percent of new diagnoses for bladder cancer are superficial, noninvasive bladder cancer, according to the National Cancer Institute. If the cancer spreads further into the muscle wall of the bladder or to nearby lymph nodes and organs, it is called invasive bladder cancer.",
        "symptoms": ["Blood in the urine (hematuria)", "painful urination", "skin irritation", "urinary tract infection", "lower back pain"],
        "url": "https://en.wikipedia.org/wiki/bladder_cancer"
    },
    "Breast Cancer": {
        "summary": "Breast cancer is an uncontrolled growth of cells that starts in the breast tissue. About one in eight women in the United States will develop the condition in her lifetime, according to the National Institutes of Health. It is the second most common cancer in women, after skin cancer, and in 2014 more than 232,000 U.S. women were diagnosed with the condition, according to the National Cancer Institute. Breast cancer is most commonly diagnosed in women ages 55 to 64. The disease can also occur in men, but it is much less common: Male breast cancer accounts for less than 1 percent of all breast cancer cases, according to NCI.",
        "symptoms": ["lump in the breast or armpit", "swelling of the breast", "flaky skin in the nipple areas", "Nipple discharge", "skin irritation"],
        "url": "https://en.wikipedia.org/wiki/Breast_Cancer"
    },
    " Flu (influenza)": {
        "summary": "Influenza viruses cause the flu (influenza). Influenza viruses are divided into three types, designated influenza types A, B, and C. Influenza types A and B are responsible for epidemics of illness that occur almost every winter and are often associated with increased rates of hospitalization and death. Influenza type C usually causes either a very mild respiratory illness or no symptoms at all.",
        "symptoms": ["fevers", "chills", "cough", "headache"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    " Allergies": {
        "summary": "Allergies are exaggerated immune responses to environmental triggers known as allergens. Allergies are very common, and about 50 million people in North America suffer from allergies. One of the most common forms of allergy is allergic rhinitis ("hay fever"), which produces symptoms like",
        "symptoms": ["nasal congestion", "sneezing,", "throat clearing"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     " Anemia": {
        "summary": "Anemia is the condition of having less than the normal number of red blood cells or less than the normal quantity of hemoglobin in the blood. The oxygen-carrying capacity of the blood is, as a result, decreased.",
        "symptoms": ["Weakness", "Fatigue easily", "", "Experience shortness of breath"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    " Anxiety": {
        "summary": "Anxiety is a feeling of apprehension and fear characterized by physical symptoms",
        "symptoms": ["stress.", "irritability", "", "sweating"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    "Asthma": {
        "summary": "Asthma is a disease characterized by chronic inflammation of the airways. The inflammation results in narrowing of the airways and difficulty breathing. The precise cause of asthma is unknown, although it is believed to result from an interaction between inherited (genetic) and environmental factors. Those with a family history of asthma are more likely to develop the condition than those without a family history. Other risk factors for asthma include obesity, viral respiratory illness during childhood, exposure to tobacco smoke, and hay fever.",
        "symptoms": [" obesity", "tobacco smoke", "", " Wheezing"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    " Back pain": {
        "summary": "Ahere are many causes of pain in the back. Symptoms in the low back can be a result of problems in the bony lumbar spine, discs between the vertebrae, ligaments around the spine and discs, spinal cord and nerves, muscles of the low back, internal organs of the pelvis and abdomen, and the skin covering the lumbar area. Pains in the upper back can also be a result of disorders of the aorta, chest tumors, and inflammation of spine.",
        "symptoms": ["dull ache", "muscle spasm", "", "tenderness"
        "rash"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
     "Bleeding Gums": {
        "summary": "Bleeding, redness, and painful or sore gums can be a symptom of gingivitis (inflammation of the gums) that arises due to a number of different causes. Bleeding of the gums is sometimes referred to as gingival bleeding, and it may occur during brushing or flossing. The soreness can be accompanied by swelling of the gum tissues",
        "symptoms": ["hormonal changes ", "Blood-thinne",],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "bad breath": {
        "summary": "Bad breath, medically known as halitosis, is a common problem. Bad breath is usually simple and preventable. Dietary factors as well as tobacco and alcohol use may all be factors in causing bad breath. Poor oral hygiene, gum disease, tooth decay, or mouth infections can also be causes of halitosis. Infections in the lungs, sinuses, or airways can also cause bad breath due to the presence of nasal secretions that may drain into the mouth. Chronic postnasal drip, for example as occurs with sinus infections, can be a cause of bad breath. Coughing up sputum from lung infections can also cause bad breath",
        "symptoms": [" oral hygiene", "sinuses", "nasal secretions"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Blood clotting": {
        "summary": "Blood clotting is a normal process that prevents loss of blood. However, sometimes disorders of the clotting system or injuries cause blood clots to form when they are not needed. In this case, the clots may cause significant complications. Blood clots can form in the veins (blood vessels that return blood to the heart after oxygen has been used by the tissues) and in the arteries (blood vessels that carry oxygenated blood from the heart to all parts of the body). Symptoms of a blood clot depend on the location of the clot.",
        "symptoms": [" obesity", "tobacco smoke", ""],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Bladder Infection": {
        "summary": "Symptoms of a bladder infection are similar to those of any lower urinary tract infection (UTI). These symptoms are similar in men, women, and children. The main symptoms of bladder infection are",
        "symptoms": ["pain,", "discomfort", "Frequent Urination"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Blood in Urine": {
        "summary": "Blood in the urine may or may not be accompanied by pain, but it is always abnormal and should be further investigated by a health care professional. Painful blood in the urine can be caused by a number of disorders, including stones and infections in the urinary tract",
        "symptoms": ["Urine Odor", "Cloudy Urine"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Nosebleed": {
        "summary": "The nose is a part of the body that is very rich in blood vessels (vascular) and is situated in a vulnerable position on the face. As a result, any trauma to the face can cause a bloody nose, and bleeding may be profuse. Nosebleeds can occur spontaneously when the nasal membranes dry out, crust, and crack, as is common in dry climates, or during the winter months when the air is dry and warm from household heaters",
        "symptoms": ["Nasal Congestion", "Jaw Paine", "alcohol abuse"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Brittle Nails": {
        "summary": "Many medical conditions can affect the shape or texture of the fingernails. Brittleness of the nails, meaning that the nails easily become cracked, chipped, split, or peeled, can be observed as a sign of aging or in response to the long-term use of nail polish or exposure to moist conditions (including frequent swimming or dishwashing)",
        "symptoms": ["Dry Skin", "Nail Discoloration"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Bumps on Skin": {
        "summary": "People often describe localized swollen areas on, or under, the skin as lumps or bumps. While bumps on, or under, the skin may result from conditions that give rise to a skin rash, many other conditions can result in solitary raised lumps on the skin. Infections, tumors, and the body's response to trauma or injury can all lead to lumps or bumps that appear to be located on or underneath the skin.",
        "symptoms": ["Itch", "rash"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Burning mouth syndrome": {
        "summary": "Burning mouth syndrome (BMS) is a collection of symptoms characterized by pain of the tongue, lips, or palate. It also may involve a general feeling of discomfort of the whole mouth. The burning or pain can occur every day over a long period of time. Some people feel the pain every day. Other sensations that have been described with BMS include",
        "symptoms": ["scalding", "ttingling",],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Burning Urination": {
        "summary": "Burning urination or painful urination is also referred to as dysuria. A burning sensation with urination can be caused by infectious (including sexually transmitted infections, or STDs such as chlamydia and gonorrhea) and noninfectious conditions, but it is most commonly due to bacterial infection of the urinary tract affecting the bladder.",
        "symptoms": ["Dark Urine"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Buttock Pain": {
        "summary": "Many conditions and diseases can cause pain in the buttocks, commonly known as butt pain. Causes of pain in the buttocks range from temporary annoyances, such as bursitis, bruising, piriformis syndrome, muscle strain, and shingles, to more serious diseases with long-term consequences, such as cancer, arthritis of the sacroiliac joints, and herniated disc with sciatica.",
        "symptoms": ["Muscle Cramps", "hip pain"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "cellulitis": {
        "summary": "The symptoms of cellulitis result from inflammation of the skin and underlying tissues. The skin itself may appear reddened and warm to the touch, and there may be swelling, pain, and tenderness of the affected area. Red streaks on the skin can sometimes be seen when the infection is spreading.",
        "symptoms": ["Swelling"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Sore throat": {
        "summary": "Sore throat is most commonly an acute process that is the result of an infection such as the common cold or infectious mononucleosis. However, some chronic conditions like gastroesophageal reflux, some cancers, chronic tonsillitis, and other conditions can lead to sore throat symptoms that last longer and persist (chronic sore throat)",
        "symptoms": ["mouth sores", "difficulty swallowing"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Cold": {
        "summary": "The common cold refers to a viral infection of the upper respiratory tract. Characteristic symptoms include",
        "symptoms": [" Low-grade fever", "Watery eyes"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Confusion": {
        "summary": "Confusion is a change in mental status in which a person is not able to think with his or her usual level of clarity. Frequently, confusion leads to the loss of ability to recognize people and or places, or tell time and the date. Feelings of disorientation are common in confusion, and decision-making ability is impaired",
        "symptoms": ["Memory Loss","Paranoia"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Constipation": {
        "summary": "Constipation means different things to different people. For many people, it simply means infrequent stools. For others, however, constipation means hard stools, difficulty passing stools (straining), or a sense of incomplete emptying after a bowel movement. The cause of each of these types of constipation probably is different, and the approach to each should be tailored to the specific type of constipation",
        "symptoms": [" Diarrhea", "Stomach Cramps"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Joint Cracking ": {
        "summary": "The symptom of joint cracking is described differently by different people while nevertheless representing the same condition. Various descriptions for the same process include popping, exploding, noise, snapping, and creaking of a joint. The cause of joint cracking depends on a number of conditions",
        "symptoms": ["Joint Stiffness", "Joint Swelling"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     "Cyanosis(Turning Blue)": {
        "summary": "Cyanosis is the medical term for a bluish color of the skin and the mucous membranes due to an insufficient level of oxygen in the blood. For example, the lips and fingernails may show cyanosis. Cyanosis can be evident at birth due to the presence of a heart malformation that permits blood that is not fully oxygenated to enter the arterial circulation. ",
        "symptoms": ["Skin Discoloration", "Depigmentation Of Skin"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Dark Circles": {
        "summary": "Dark circles under the eyes are a common complaint of both men and women, although they can occasionally be seen in children. As people age, the skin becomes thinner and collagen is lost, sometimes enhancing the appearance of blood vessels beneath the eyes and making the area appear darker. Dark circles under the eyes are not necessarily a sign of tiredness, but stress and fatigue seem to worsen the facial appearance of many people, including their tendency to develop dark circles.",
        "symptoms": ["Insomnia", "Fatigue"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Dehydration": {
        "summary": "Symptoms and signs of dehydration can be minor, such as increased thirst, or severe and life-threatening, depending on the extent of the dehydration. Along with thirst, initial symptoms of dehydration include reduced urine output and darkening of the urine as it becomes more concentrated",
        "symptoms": [" vomiting", " excessive sweating", "burns"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Delusions": {
        "summary": "A delusion is a false personal belief that is not subject to reason or contradictory evidence and is not explained by a person's usual cultural and religious concepts (so that, for example, it is not an article of faith). A delusion may be firmly maintained in the face of incontrovertible evidence that it is false. Delusions are common in psychotic disorders such as schizophrenia. Delusions can also be a feature of brain damage or disorders.",
        "symptoms": [" psychotic disorder", "brain damage"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Dengue": {
        "summary": "Dengue infection is a leading cause of death and sickness in tropical and subtropical parts of the world. Dengue hemorrhagic fever is a more serious form of dengue infection.",
        "symptoms": ["severe pain", " breathing problems", " low back pain"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Depression": {
        "summary": "Depression is an illness that involves the body, mood, and thoughts and affects the way a person eats and sleeps, the way one feels about oneself, and the way one thinks about things. Depressive disorders are characterized by pervasive mood changes that affect all aspects of an individual's daily functioning. A depressive disorder is not the same as a passing blue mood and is more than a case of persistent sadness.",
        "symptoms": ["sleep problems", "Suicidal Thoughts"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Diarrhea": {
        "summary": "Diarrhea is a familiar phenomenon defined as unusually frequent or unusually soft or liquid bowel movements. It is the opposite of constipation. The word diarrhea with its odd spelling is a near steal from the Greek diarrhoia meaning a flowing through.",
        "symptoms": ["Blood In Stool", "watery stool"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Dizziness": {
        "summary": "Dizziness is a feeling of being lightheaded or woozy. Disturbances of the brain, gastrointestinal system, vision, and the vestibular system of the inner ear are known causes of dizziness. People often refer to dizziness as vertigo, unsteadiness, or lightheadedness.",
        "symptoms": ["Fainting", "Unsteady Gait"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Double Vision": {
        "summary": "Double vision, or "seeing double," occurs when two nonmatching images are sent to the part of the brain that is responsible for processing visual input. If this occurs over the long term, the brain will eventually compensate for the two signals by suppressing one signal, so that a single image is perceived. The suppressed eye may eventually become amblyopic (lazy eye) with resultant vision loss.",
        "symptoms": ["Vision Loss", "Tunnel Vision"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
     
     "Hyperglycemia (High Blood Sugar)": {
        "summary": "Hyperglycemia is the term that refers to an abnormally high level of sugar, or glucose, in the blood. Diabetes mellitus types 1 and 2 are by far the most common causes of hyperglycemia. In patients with either type 1 or type 2 diabetes, metabolic abnormalities lead to an elevation in blood glucose levels. When there is too much glucose in the blood, this can lead to a number of health risks and other symptoms",
        "symptoms": ["thirst", "frequent urination"],
        "url": "https://en.wikipedia.org/wiki/influenza"
    },
    
    "Endocarditis": {
        "summary": "Endocarditis, an inflammation of the valves of the heart, causes symptoms that can be nonspecific and similar to those of many other conditions. For example, fever, malaise, weakness, and shortness of breath are common symptoms of endocarditis.",
        "symptoms": ["night sweats", "pale skin"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
       
    "Enlarged Heart": {
        "summary": "An enlarged heart is medically known as cardiomegaly. Cardiomegaly can be caused by a number of different conditions, including diseases of the heart muscle or heart valves, high blood pressure, arrhythmias, and pulmonary hypertension. Cardiomegaly can also sometimes accompany longstanding anemia and thyroid diseases, among other conditions. So-called infiltrative diseases of the heart, for example, in which abnormal proteins (amyloidosis) or excess iron (hemochromatosis) accumulate within the tissues of the heart, can also cause an enlargement of the heart. Infections, nutritional deficiencies, toxins (such as alcohol or drugs), and some medications have been associated with cardiomegaly. In some situations (for example, pregnancy), there can be a temporary increased demand on the heart, resulting in some temporary enlargement.",
        "symptoms": ["abnormal proteins", "drugs"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

      "Yawning": {
        "summary": "Yawning is the involuntary opening of the mouth while taking in a long breath of air. Yawning is associated with sleepiness or drowsiness. Almost anything that causes drowsiness, ranging from tiredness to certain medications, can lead to yawning. Conditions like sleep apnea and restless legs syndrome can cause yawning due to daytime sleepiness. Excessive yawning is yawning that occurs beyond the amount expected even for someone who is sleepy.",
        "symptoms": [" sleep apnea", "drowsiness"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Eye Floaters": {
        "summary": "Eye floaters are spots, strings, flecks, or specks that appear like floating material in the field of vision. Some people describe them as blobs, cobwebs, or O-shaped or C-shaped spots. They appear to drift or move slowly around the field of vision. Eye floaters are typically not dangerous, but in some cases, they may be signs of a serious problem. Floaters appear when tiny areas of the gelatinous material (known as vitreous) in the back of the eye break loose. These tiny pieces cast shadows on the retina that appear as floaters. Vitreous syneresis describes a process that occurs with aging in which the vitreous gel naturally undergoes some liquefaction, resulting in small pockets of more liquid vitreous within the firmer gel. The boundary between these liquid pockets and the gel may be perceived as an eye floater.",
        "symptoms": ["aging "],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Eye Pain": {
        "summary": "The eye is the organ of sight. Eye pain can be cause by conditions involving the eyeball (orbit) or be caused by conditions of structures around the eyeThe optic nerve is the nerve that connects the eye to the brain and carries the impulses formed by the retina to the visual cortex of the brain.The choroid is a thin vascular layer between the sclera and the retina that supplies blood to the retina and conducts arteries and nerves to other structures in the eye.",
        "symptoms": ["Eye Discharge", "Eye Twitch"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Eyestrain": {
        "summary": "Eyestrain (or eye strain) describes a condition in which eye symptoms occur as a result of extended use of the eyes. Eye discomfort, dry eyes, blurred vision, and headaches are common symptoms of eyestrain. Eyestrain is not a disease but a symptom that occurs when the eyes are used for a long period of time. The medical term for eyestrain is asthenopia. In people who suffer from eyestrain, a lack of sleep, certain medications, physical or emotional stress, or being tired can make the symptoms worse.",
        "symptoms": ["blurred vision", "dryness"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Fainting (Syncope)": {
        "summary": "Fainting (syncope) is the partial or complete loss of consciousness with interruption of awareness of oneself and ones surroundings. When the loss of consciousness is temporary and there is spontaneous recovery, it is referred to as syncope or, in nonmedical terms, fainting. Syncope accounts for one in every 30 visits to an emergency room. It is pronounced sin-ko-pea",
        "symptoms": ["Dizziness", "black out"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Zika Virus Infection": {
        "summary": "The Zika virus is transmitted to humans by the bite of a mosquito that carries the virus. When it causes symptoms (in about one out of every five infections), it typically produces a disease that lasts a few days to a week. Common Zika fever symptoms and signs include",
        "symptoms": ["redness of the eyes", "yellow fever"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Finger Pain": {
        "summary": "Finger pain can be caused by disease or injury affecting any of the structures in the finger, including the bones, muscles, joints, tendons, blood vessels, or connective tissues. Joint pain is a feature of joint inflammation (arthritis) that may occur in the joints of the finger bones. This can sometimes be accompanied by redness, swelling, or warmth of the joints.",
        "symptoms": ["Toe Pain", "Wrist Pain"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Mood Swings": {
        "summary": "Mood swings refer to rapid changes in mood. The term may refer to minor daily mood changes or to significant mood changes as seen with mood disorders such as major depression or bipolar depression. Mood swings can also occur in women who suffer from premenstrual syndrome or premenstrual dysphoric disorder. The menopausal transition, specifically the time around approaching menopause or perimenopause, is associated with mood swings in some women. Mood swings can be seen with other conditions as well, including schizophrenia, attention deficit hyperactivity disorder, dementia, and thyroid conditions",
        "symptoms": [" bipolar depression", " thyroid"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Foot Pain": {
        "summary": "Pain in the foot can involve any part of the foot. Abnormalities of the skin, nerves, bones, blood vessels, and soft tissues of the foot can result in foot pain. Evaluating the cause of foot pain can require an understanding of the anatomy and physiology of not only the foot, but also the ankle, lower extremity, and lower spine.",
        "symptoms": ["Heel Pain", "Foot Swelling"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Foreign Body in the Eye": {
        "summary": "A foreign body in the eye is anything that is lodged in any part of the eye. Usually foreign bodies are metal, glass, or organic material (such as insects). Depending upon the size and type of material that gets into the eye, it may be a minor irritation or can cause serious medical consequences. Foreign bodies may cause bleeding into the eye. Bleeding into the whites of the eye is due to blood collection in or under the conjunctiva, the lining membranes of the eye. Blood over the iris (colored part) of the eye is known as a hyphema. This is often a sign of a serious eye injury.",
        "symptoms": [ "bleeding into the eye"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Gallbladder Attack": {
        "summary": "The symptoms of gallbladder attack result most commonly due to the presence of gallstones. Less common causes include tumors of the bile duct or gallbladder or certain illnesses. With blockage to the flow of bile, the bile accumulates in the gallbladder, causing an increase in pressure that can sometimes lead to rupture. Symptoms of a gallbladder attack include pain in the upper right side or middle of the abdomen. The pain may be dull, sharp, or cramping. The pain typically starts suddenly. It is steady and may spread to the back or the area below the right shoulder blade. Having steady pain particularly after meals is a common symptom of gallbladder stones. Movement does not make the pain worsen",
        "symptoms": ["clay-colored stools", " jaundice"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Intestinal Gas": {
        "summary": "The ability to belch is almost universal. Belching, also known as burping, is the act of expelling gas from the stomach out through the mouth. The usual cause of belching is a distended (inflated) stomach caused by swallowed air. The distention of the stomach causes abdominal discomfort, and the belching expels the air and relieves the discomfort. The common reasons for swallowing large amounts of air (aerophagia) are gulping food or drink too rapidly, anxiety, and carbonated beverages",
        "symptoms": ["Bloating ", "belching"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Gastritis": {
        "summary": "Gastritis, or inflammation of the lining tissues of the stomach, can be either acute (coming on suddenly) or chronic (causing symptoms over a long period of time). Symptoms include upper abdominal, or epigastric pain, and burning and heartburn. The pain may get worse with eating. Nausea and vomiting sometimes occur along with the pain. Symptoms of chronic gastritis include",
        "symptoms": ["weight loss", "Heartburn"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Gastroenteritis (Stomach Flu)": {
        "summary": "Gastroenteritis, sometimes referred to as "stomach flu," is irritation and inflammation of the stomach and intestines. While viruses are common causes of gastroenteritis, the condition has nothing to do with the influenza virus, so the term stomach flu is a misnomer. Rotavirus and norovirus are the two most common types of virus that cause gastroenteritis",
        "symptoms": ["Bacterial infection", "watery diarrhea"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Gum disease": {
        "summary": "Gum disease is inflammation of the gums. Gum disease can also be referred to as periodontal (around the teeth) disease, periodontitis (inflammation of areas around the teeth), and gingivitis (inflammation of the gums). Gingivitis and periodontitis are two different types of gum disease that vary in severity. Mild gum disease (gingivitis) simply causes redness or occasional bleeding during toothbrushing. In more serious cases of gum disease, there is damage to the soft tissues and bones that support the teeth (periodontitis), leading to separation of the teeth from the gums. The separated areas, or pockets, easily become irritated and inflamed. Severe cases of gum disease can result in tooth loss",
        "symptoms": [" cigarette smoking", "flossing"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hair Loss": {
        "summary": "There are many types of alopecia (baldness or hair loss), each with a different cause. Alopecia may be localized to the front and top of the head, as in common male pattern baldness. It may be patchy, as in a condition called alopecia areata. Or it can involve the entire head, as in alopecia capitis totalis (also called alopecia totalis), and it can involve hair loss of the entire body, such as in alopecia universalis",
        "symptoms": ["Dry Skin", "Flaky Scalp"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hairy Tongue": {
        "summary": "Hairy tongue, medically known as lingua villosa, is generally a harmless condition that alters the appearance of the tongue, making it appear discolored and furry. Hairy tongue is also commonly referred to as black hairy tongue (lingua villosa nigra), but the tongue discoloration may appear white, brown, pink, or green.",
        "symptoms": ["Loss Of Taste", "Tongue Swelling"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hearing Loss": {
        "summary": "Hearing loss can be present at birth (congenital) or become evident later in life (acquired deafness). The distinction between acquired and congenital deafness specifies only the time that the deafness appears. It does not specify whether the cause of the deafness is genetic (inherited).",
        "symptoms": ["genetic deafness", "Damage from noise"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Heart Attack in Men": {
        "summary": "Pain, discomfort, and pressure in the chest are the most common symptoms of heart attack in men. These can include a sensation of fullness or squeezing in the chest. These symptoms are sometimes accompanied by pain in one or both arms, the jaw, back, stomach, or neck. While women are more likely than men to experience symptoms other than the characteristic chest pain and pressure, men can also experience other types of symptoms or mistake a heart attack for another condition, such as gastroesophageal reflux",
        "symptoms": ["chest pain", "pressure in the upper back"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Heart Attack in Women": {
        "summary": "The classic symptoms of heart attack include a feeling of extreme pressure on the chest and chest pain, including a squeezing or full sensation. This can be accompanied by pain in one or both arms, jaw, back, stomach, or neck. Other symptoms of heart attack include shortness of breath, nausea, vomiting, lightheadedness, and a sweating feeling, often described as breaking out in a cold sweat. Although chest pain and pressure are the characteristic symptoms, women are somewhat more likely than men to experience heart attack that does not occur in this typical fashion. Instead, some women with heart attacks may experience more of the other symptoms, like lightheadedness, nausea, extreme fatigue, fainting, dizziness, or pressure in the upper bac",
        "symptoms": [" coronary artery", "high cholesterol"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Gastroesophageal Reflux Disease ": {
        "summary": "Heartburn is an uncomfortable feeling of burning and warmth behind the breastbone (sternum) but sometimes rising as high as the neck. It usually occurs after meals, when lying down, or at night while sleeping. Heartburn usually is due to gastroesophageal reflux disease (GERD), the rise of stomach acid back up into the esophagus. Heartburn has nothing whatsoever to do with the heart though the discomfort of heartburn may be confused with heart pain and vice versa. Heartburn is a popular nonmedical term that often is referred to medically as pyrosis",
        "symptoms": ["Dysphagia", "Dyspepsia"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "High Blood Pressure (Hypertension)": {
        "summary": "High blood pressure, or hypertension, most commonly occurs without any symptoms and has for this reason been referred to as the silent killer. Uncomplicated hypertension can persist for years, even decades, without causing symptoms. However, when complications of the condition begin to develop due to damage to the vascular system, symptoms can occur. Symptoms of complicated hypertension (high blood pressure) can include dizziness, shortness of breath, headache, and blurred vision. Other possible symptoms are nosebleeds, blood in the urine, fatigue, chest pain, and a pounding sensation in the neck, chest, or ears",
        "symptoms": ["kidney failure", "swear headache"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hoarseness": {
        "summary": "Hoarseness is a harsh, rough, raspy quality to the voice. Hoarseness is generally caused by irritation of, or injury to, the vocal cords. This trauma to the vocal cords leads to a change in the pitch of the voice. The voice box, or larynx, is the portion of the respiratory (breathing) tract containing the vocal cords that produce sound. It is located between the pharynx and the trachea. The larynx, also called the voice box, is a 2-inch-long, tube-shaped organ in the neck",
        "symptoms": ["tuberculosis", "chronic sinusitis"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hyperthermia": {
        "summary": "Symptoms of hyperthermia, or heat-related illness, vary according to the specific type of illness. The most severe form of hyperthermia is heat stroke. This happens when the body is no longer able to regulate its internal temperature; this is a medical emergency. The body temperature may be over 105 F, a level that damages the brain and other organs. Other symptoms include muscle cramps, fatigue, dizziness, headache, nausea, vomiting, and weakness.",
        "symptoms": ["heat stroke"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hyperventilation": {
        "summary": "Hyperventilation refers to overbreathing, in which ventilation exceeds the metabolic demand, and its related physiological consequences. Excessive breathing can cause dizziness, lightheadedness, weakness, shortness of breath, a sense of unsteadiness, muscle spasms in the hands and feet, and a tingling feeling around the mouth and fingertips. All of these symptoms are the result of abnormally low levels of carbon dioxide in the blood caused by overbreathin",
        "symptoms": ["Breadth Shortness", "Wheezing"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Hypothyroidism": {
        "summary": " Patients with hypothyroidism may also report aches and pains, swelling in the legs, and difficulty concentrating. Menstrual dysfunction, hair loss, decreased sweating, decreased appetite, mood changes, blurred vision, and hearing impairment are also possible symptoms. Later symptoms (when the condition worsens) can include puffiness around the eyes, slow heart rate, lowered body temperature, and heart failure.",
        "symptoms": ["Weight Gain", "cold intolerance"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

  "Impulsivity": {
        "summary": "Impulsivity is the tendency to act on impulse -- that is, without forethought about the appropriateness or consequences of the action. A certain degree of impulsivity is common in children and even some young adults often display impulsivity of behavior. Only when present to excess and accompanied by problems with normal function is impulsivity considered abnormal in young children. Impulsivity can be manifested in an action or in interruptin",
        "symptoms": ["restlessness" "inattention"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Inattention": {
        "summary": "Inattention is the lack of focus when focus on a given event or situation is required. Inattention is a hallmark feature of attention deficit-hyperactivity disorder (ADHD), which can affect adults as well as children and teens. Inattention in ADHD is often accompanied by symptoms such as restlessness, problems doing quiet activities, problems with executive function, talking excessively, and fidgeting. Inattention can also occur due to external factors such as distractions as well as situations of emotional stress, anxiety, conflict, anger, or other mood changes.",
        "symptoms": ["dementia", "anger"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Urinary Incontinence": {
        "summary": "Urinary incontinence is the unintentional loss of urine. Incontinence results from an inability to hold urine in the bladder due to loss of voluntary control over the muscles (urinary sphincters) around the opening of the urine tube (ureter).",
        "symptoms": ["Painful Urination"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Increased Appetite": {
        "summary": "An increase in appetite can be a normal physiological response that occurs, for example, in children and adolescents during periods of growth or following strenuous activity or excessive caloric demand. In some cases, an increase in appetite can be a sign of an abnormal condition, such as some endocrinologic conditions, including diabetes, hyperthyroidism, and Graves' disease",
        "symptoms": ["hyperthyroidism", "excessive hunger"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Insomnia": {
        "summary": "Insomnia is the perception of inadequate or poor-quality sleep. It can be due to problems falling asleep, early wakening, waking frequently during the night, unrefreshing sleep, or a combination of these. Contrary to some popular beliefs, insomnia is not defined by the total amount of sleep one gets or how long it takes a person to fall asleep. Individuals can vary in their need for sleep, and in the time required to fall asleep. What is a refreshing night's sleep for one person might be insomnia for another person.",
        "symptoms": ["early wakening", " unrefreshing sleep"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Insulin Resistance": {
        "summary": "Insulin resistance means that the cells of the body have become resistant to the action of the hormone insulin. Insulin, secreted by the pancreas, is critical for the body's use of glucose for energy. When the cells of the body do not respond appropriately to insulin, glucose from the bloodstream cannot be taken up by cells and used for fuel. Consequently, the pancreas tries to compensate by producing even more insulin. When the pancreas cannot produce enough insulin, blood glucose levels rise.",
        "symptoms": ["Inactivity", "Metabolic syndrome"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Itching": {
        "summary": "Itching is a symptom we have all experienced. Nevertheless, itching can be difficult for a person to describe to others. While itching symptoms vary, it typically leads to a peculiarly uncomfortable skin sensation. It may feel as if something is crawling on (or in) your skin. Itching can be diffuse (generalized all over the body) or localized -- all over or confined to a specific spot -- and there are many causes of diffuse and localized itching",
        "symptoms": ["skin redness", "spots on the skin"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Jaundice": {
        "summary": "Jaundice, also referred to as icterus, is the yellow staining of the skin and sclerae (the whites of the eyes) by abnormally high blood levels of the bile pigment, bilirubin. The yellowing extends to other tissues and body fluids and also may turn the urine dark. Yellowing of only the skin also can be caused by eating too many carrots or drinking too much carrot juice.",
        "symptoms": ["Dark Urine", "Skin Discoloration"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Joint Redness": {
        "summary": "Redness of the joints refers to redness of the skin surrounding a joint",
        "symptoms": ["swelling of the joints", "limited range of motion"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Joint Stiffness": {
        "summary": "Joint stiffness is the sensation of difficulty moving a joint or the apparent loss of range of motion of a joint. Joint stiffness often accompanies joint pain and/or swelling. Depending on the cause of joint stiffness, joint redness, tenderness, warmth, tingling, or numbness of an affected area of the body may be present. Joint stiffness can be caused by injury or disease of the joint and is a common finding in the arthritis conditions",
        "symptoms": [" injuries"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "kidney cancer": {
        "summary": "Symptoms of kidney cancer include blood in the urine, giving the urine a rusty, pink, or dark red appearance. Persistent pain in the side (flank) is another common symptom, along with an abdominal mass or lump, fever, weight loss, tiredness, and a general feeling of being unwel",
        "symptoms": ["cysts", "benign tumor"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "kidney stone": {
        "summary": "A kidney stone does not usually cause symptoms when it remains in the kidney. However, when a stone moves from the kidney into the ureter, it can cause a blockage of flow of urine, increasing pressure and swelling within the kidney and leading to the symptoms of kidney stones.",
        "symptoms": ["urinary urgency", "testicular pain"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Limping": {
        "summary": "Limping refers to any type of difficulty that occurs while walking. Limping can be considered to be a form of walking that favors the use of one leg over another and is most commonly due to diseases of or damage to the legs and feet, including all of the structures such as muscles, bones, joints, blood vessels, and nerves that make up the lower extremities.",
        "symptoms": ["bone fractures", "congenital malformations"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Low Blood Pressure (Hypotension)": {
        "summary": "Symptoms of low blood pressure, medically known as hypotension, relate to decreased blood flow to many areas of the body.",
        "symptoms": ["angina", "Fast breathing"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Low Testosterone": {
        "summary": "Testosterone is a natural hormone produced by the testes in men; it is also produced in small amounts by the ovaries in women. Having low levels of testosterone is a condition that has been described in both men and women. Low testosterone levels can be caused by problems with the testes and ovaries themselves or conditions that affect the pituitary gland and hypothalamus of the brain. Aging is also a known cause of low testosterone in men, and obesity can also lower testosterone levels",
        "symptoms": ["erectile dysfunction", "infertility"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Systemic Lupus": {
        "summary": "Symptoms of systemic lupus erythematosus (SLE, often referred to as simply lupus) can be quite different, because there are different types of lupus, and not all affected people show the same symptoms. Nevertheless, there are certain symptoms and signs commonly associated with the condition",
        "symptoms": ["muscle aches,", " cold exposure"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Menstrual Cramps": {
        "summary": "Menstrual cramps are the cramping in the lower abdomen, usually in the first or second day of the menstrual cycle. These are caused contractions of the uterus as it expels its unneeded contents, and also by the passage of clotted blood through the cervix. Ibuprofen (Advil) or other pain relievers can reduce the severity of cramps; some women report that exercise is also helpful.",
        "symptoms": ["Vaginal Pain", "Vaginal Bleeding"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
      "Miscarriage": {
        "summary": "The hallmark symptom of miscarriage, also known as spontaneous abortion or early pregnancy loss, is vaginal bleeding. The bleeding may be very heavy, and blood clots and/or tissue may be passed along with the bleeding. The bleeding is usually accompanied by abdominal pain and cramping. The pain may radiate to the low back, vagina, pelvic area, or buttocks. Fever and chills are not common but may occur if the miscarriage is a result of an infection.",
        "symptoms": ["cigarette smoking", "high alcohol consumption"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    "Spasticity": {
        "summary": "Spasticity is a condition of increased muscle tone in which muscles acquire a state of near constant contraction, or activity. Muscle spasticity causes a loss of range of motion of the affected area and a loss of function. ",
        "symptoms": ["stiffness", "tightness"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Nail Fungus": {
        "summary": "The term fungal nails, medically known as onychomycosis, refers to a fungal infection of the toenails or fingernails. Fungal infection of the nails may cause changes in the nail itself and its appearance, including symptoms and signs",
        "symptoms": ["thickening", "flaking"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Numbness Toes": {
        "summary": "Numbness of the toes generally is a result of conditions that affect the nerves and/or blood vessels that supply the foot. Numbness of the toes is often associated with tingling. Numbness and tingling sensations in the toes is referred to as paresthesia of the toes.",
        "symptoms": ["Swollen Feet", "Cold Feet"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Hand and Finger Numbness": {
        "summary": "Numbness of the fingers and/or hands typically is a result of conditions that affect the nerves and/or blood vessels that supply the hand. Numbness of the fingers or hands is often associated with tingling. These symptoms are referred to as paresthesia of the fingers. Peripheral neuropathy is damage to the nerves of the extremities that often results in numbness or tingling. Longstanding or uncontrolled diabetes is one of the major causes of peripheral neuropathy",
        "symptoms": [" stroke", "multiple sclerosis"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Enterovirus (Non-Polio Enterovirus Infection)": {
        "summary": "Many people who become infected with non-polio enteroviruses either have no symptoms from the infection or experience only a mild illness. When symptoms do occur, they often resemble those of the common cold",
        "symptoms": ["malaise", "sensitivity to light"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Ovarian cancer": {
        "summary": "Ovarian cancer may not cause any specific signs or symptoms, particularly in its early stages. When it does cause symptoms, these may be nonspecific and vague",
        "symptoms": ["changes in bowe", "early satiety"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Osteopenia": {
        "summary": "Osteopenia is a bone condition characterized by a decreased density of bone, but the density is not decreased enough to warrant a diagnosis of osteoporosis. Osteopenia leads to bone weakening and an increased risk of breaking a bone (fracture). Osteopenia represents a lesser degree of bone loss than osteoporosis. When there are other risk factors present (like corticosteroid medication use, smoking, or other bone conditions) that also increase the risk of bone fractures, medications may be required",
        "symptoms": ["arthritis", "genetic predisposition"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Pale skin": {
        "summary": "Paleness of the skin refers to an abnormal lightening of the skin or mucous membranes. Pale skin may be generalized (occurring all over the body) or localized to one area. It is often accompanied by paleness or pallor in the linings of the eyes, inside of the mouth, and on the surface of the tongue. True paleness of the skin is related to the thickness and density of blood vessels beneath the skin and not to the amount of melanin (skin pigment) that is present. However, some people may confuse loss of skin pigmentation (as with albinism) with paleness. In dark-skinned people, paleness may only be apparent when examining the mucous membranes. Pale skin generally results from a decrease in blood flow, as with fainting or shock.",
        "symptoms": ["Cyanosis/Turning Blue"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Paralysis": {
        "summary": "Paralysis is the loss or impairment of voluntary muscular power. Paralysis can result from either diseases involving changes in the makeup of nervous or muscular tissue or those that are the result of metabolic disturbances that interfere with the function of nerves or muscles. Depending upon the cause, paralysis may affect a specific muscle group or region of the body, or a larger area may be involved. When only one side of the body is affected, the condition is known as hemiplegia. In other instances, both sides of the body may suffer the effects, leading to diplegia or bilateral hemiplegia. When only the lower limbs are affected by paralysis, it is called paraplegia. When all four limbs are affected, it is referred to as quadriplegia. The term palsy is sometimes used to refer to the loss of muscle power in a body part",
        "symptoms": [" loss of muscle power"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Panic Attack": {
        "summary": "Panic attack symptoms come on suddenly and are unexpected. The symptoms can be severe and disabling, and those who experience panic attacks may lead to the development of irrational fears (phobias) of certain situations. Panic attack symptoms can be varied and may cause the sufferer to feel that death or a catastrophic event is imminent (a sense of impending doom).",
        "symptoms": ["physical illness", "stomach upset"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "PMS (Premenstrual Syndrome)": {
        "summary": "Premenstrual syndrome, or PMS, is a group of unpleasant symptoms linked to a woman's menstrual cycle, typically occurring one to two weeks before the menstrual period begins. PMS symptoms vary widely among women and range in severity from mild to debilitating. PMS typically includes physical and emotional symptoms.",
        "symptoms": ["sleep disturbances", "crying spells"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Poor Hygiene": {
        "summary": "Poor hygiene can be a sign of self-neglect, which is the inability or unwillingness to attend to one's personal needs. Poor hygiene often accompanies certain mental or emotional disorders, including severe depression and psychotic disorders. Dementia is another common cause of poor hygiene. Other people may develop poor hygiene habits due to social factors such as poverty or inadequacy of social support. Physical disabilities can also interfere with one's ability to care for oneself and may result in an individual being unable to attend to personal hygiene. There is no treatment for poor hygiene, although antipsychotic and antidepressant medications are used when certain mental illnesses are the cause of this behavior",
        "symptoms": ["psychotic disorders"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Malnutrition": {
        "summary": "Malnutrition is the lack of adequate nutrition, either as a result of imbalances, deficiencies, or excesses in a person's intake of food and nutrients. This can be due to eating too little, eating an improper diet, or having a medical condition that results in the body's being unable to use food and nutrients. Malnutrition can also refer to overnutrition and obesity and is the condition of being poorly nourished.",
        "symptoms": ["wound healing", "mental illness"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

   "Ptosis": {
        "summary": "A drooping or sagging of the eyelid is medically known as ptosis or blepharoptosis. Drooping eyelids may occur on both sides (bilateral) or on one side only (unilateral), in which case it is more easily noticed. Congenital ptosis is eyelid drooping that is present at birth; when it develops later, it is referred to as acquired ptosis. Depending upon the severity of the condition, drooping eyelids may be barely noticeable or quite prominent.",
        "symptoms": ["sagging of the skin"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Shaking Hands (Hand Tremors)": {
        "summary": "A tremor is an unintentional rhythmic movement of any part of the body. When hands are shaking or trembling, this is typically a tremor of the hands. Tremors are usually caused by problems with areas of the brain that control movements. Neurological problems can cause tremors, but they can also be caused by metabolic problems and toxins (such as alcohol) that affect the brain and nervous system. Shaking hands and tremor can also be a side effect of different medications.",
        "symptoms": ["Tremor", "Hand Tremor"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Swollen Eyes": {
        "summary": "Swelling of the eye, also referred to as periorbital puffiness, refers to the presence of excess fluid (edema) in the connective tissues around the eye, most commonly the eyelids. A swollen eye can result from trauma, infections, or other injuries to the eye area. Other signs and symptoms can be associated with swelling of the eye, including excess tear production or discharge, eye irritation, redness, dryness, or obstructed or impaired vision, depending on the cau",
        "symptoms": ["itchy eyes", "impaired vision"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

       "Swollen Testicles (Testicular Swelling)": {
        "summary": "Testicular swelling, like pain in the testicle, can arise from several different causes, some of which constitute a medical emergency. Testicular swelling may be perceived when there is localized enlargement of a testicle or a more generalized enlargement of the scrotum. It may be one-sided or bilateral and may or may not be accompanied by pain and other symptoms",
        "symptoms": ["Penile Itching"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },

        "Swollen Tonsils": {
        "summary": "Swollen tonsils can accompany a number of different infections of the upper respiratory tract. Some people have larger tonsils than others, and it is possible to have large tonsils without associated symptoms or problems. Tonsillitis refers to inflammation of the tonsils, which typically occurs due to infection.",
        "symptoms": ["enlarged lymph nodes", "viruses"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
        "Toothache": {
        "summary": "The symptoms of toothache include sharp pain or dull pain in or around a tooth. The most common cause of a toothache is a dental cavity as a result of tooth decay. Dental cavities and toothache can be prevented by proper oral hygiene. Another common cause of toothache is gum disease",
        "symptoms": [" shingles", "abscess"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
        "Tremors": {
        "summary": "Tremors are abnormal movements of the body that occur because of conditions affecting the nervous system.Some tremors occur at rest and become less apparent with activity. They are referred to as rest tremors. The classic rest tremor is from Parkinson's disease. Some tremors are most apparent as the extremity is lifted against gravity and not moving toward a target (for example, from hyperthyroidism, familial, and stress fear). These tremors are referred to as positional or postural tremors. Some tremors are more prominent with movement actions toward a target and are referred to as intention tremors. This is what occurs with disease or damage to the cerebellum of the brain",
        "symptoms": ["Seizure", " stress fear"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
        "Tunnel Vision": {
        "summary": "Tunnel vision occurs when one loses visual acuity in the peripheral visual fields while retaining visual acuity in the central regions. The vision can be considered to be constricted and concentrated in the central area, as when one is inside a tunnel looking out. Tunnel vision can be caused by any type of damage to the optic nerve, to the retina of the eye, or to areas in the brain responsible for processing of visual input.",
        "symptoms": ["Glaucoma ", "Double Vision"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
        "Vomiting": {
        "summary": "Vomiting, along with nausea, is a symptom of an underlying disease rather than a specific illness itself. Emesis is the medical term for vomiting. Vomiting is the forcible emptying of the stomach in which the stomach has to overcome the pressures that are normally in place to keep food and secretions within the stomach. Causes of vomiting are varied and include food-borne illnesses (food poisoning), infections, problems with the brain and central nervous system, and systemic (body-wide) diseases. ",
        "symptoms": ["pneumonia", "sepsis"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
    
        "Vomiting Blood": {
        "summary": "The medical term for vomiting blood (bloody vomit) is hematemesis. Blood in vomit can be due to minor or major health problems. It can be minimal or great in amount. Vomiting blood should be evaluated by a health care professional.",
        "symptoms": ["stomach ulcer", "gastritis"],
        "url": "https://en.wikipedia.org/wiki/influenza" 
    },
}


