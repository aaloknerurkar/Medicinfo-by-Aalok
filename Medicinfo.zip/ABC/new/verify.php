<?php 
/* Verifies registered user email, the link to this page
   is included in the register.php email message 
*/